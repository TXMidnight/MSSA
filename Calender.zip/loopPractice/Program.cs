﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace loopPractice
{
    class Program
    {
        static void Main(string[] args)
        {

            //placeholder values later decided not to use.
            //int d = 0;
            //int m = 0;
            //int y = 0;
            
            //Asking for entry on the day
            Console.WriteLine("Enter a day: ");
            string inpD = Console.ReadLine();
            int nD = Convert.ToInt32(inpD);
            //Asking for entry on the month
            Console.WriteLine("Enter a month: ");
            string inpM= Console.ReadLine();
            int nM = Convert.ToInt32(inpM);
            //Asking for entry on the year
            Console.WriteLine("Enter a Year: ");
            string inpY = Console.ReadLine();
            int nY = Convert.ToInt32(inpY);
            //Asking for entry on how many days to add
            Console.WriteLine("Please enter how many days to add: ");
            string inpadd = Console.ReadLine();
            int added = Convert.ToInt32(inpadd);

            Console.WriteLine($"The date is {nM}-{nD}-{ nY}");
            Console.WriteLine("We are adding {0} days", added);
            //newD(ate) is for the updated date
            int newD = nD + added;
            if (true)
            {
                // the whole # region function does not work because i couldnt figure out what i was doing wrong.
                //its also not complete because i havent figured out how to make the days reset...
                //thinking if the day value is over the allowed values for that month, subtract allowed day and plus the remainder to 0 and start fresh in a new month.
                #region MONTHS IN HERE
               if (nM == 1)
                {
                    if (nD > 31)
                    {
                        nM = 2;
                        int thisd = nD - 31;
                    }
                    else
                    {
                        nM = 1;
                    }
                    int Jan = 31;
                    int mon = Jan;
                }
                else if (nM == 2)
                    //checking for leap year...NOT COMPLETE
                    if (nY == 2020 || nY == 2024 || nY == 2028 || nY == 2032)
                    {
                        if (nD > 29)
                        {
                            nM = 3;
                        }
                        int Feb = 29;
                    }
                    else if (nD <= 28)
                    {
                        if (nD > 28)
                        {
                            nM = 3;
                        }
                        else if (nD < 28)
                        {
                            nM = 2;
                        }
                        int Feb = 28;
                    }
                    else if (nM == 3)
                    {
                        if (nD > 31)
                        {
                            nM = 4;
                        }
                        else
                        {
                            nM = 3;
                        }
                        int Mar = 31;
                        int mon = Mar;
                    }
                    else if (nM == 4)
                    {
                        if (nD > 30)
                        {
                            nM = 5;
                        }
                        else
                        {
                            nM = 4;
                        }
                        int Apr = 30;
                        int mon = Apr;
                    }
                    else if (nM == 5)
                    {
                        if (nD > 31)
                        {
                            nM = 6;
                        }
                        else
                        {
                            nM = 51;
                        }
                        int May = 31;
                        int mon = May;
                    }
                    else if (nM == 6)
                    {
                        if (nD > 30)
                        {
                            nM = 7;
                        }
                        else
                        {
                            nM = 6;
                        }
                        int Jun = 30;
                        int mon = Jun;
                    }
                    else if (nM == 7)
                    {
                        if (nD > 31)
                        {
                            nM = 8;
                        }
                        else
                        {
                            nM = 7;
                        }
                        int Jul = 31;
                        int mon = Jul;
                    }
                    else if (nM == 8)
                    {
                        if (nD > 31)
                        {
                            nM = 9;
                        }
                        else
                        {
                            nM = 8;
                        }
                        int Aug = 31;
                        int mon = Aug;
                    }
                    else if (nM == 9)
                    {
                        if (nD > 30)
                        {
                            nM = 10;
                        }
                        else
                        {
                            nM = 9;
                        }
                        int Sep = 30;
                        int mon = Sep;
                    }
                    else if (nM == 10)
                    {
                        if (nD > 31)
                        {
                            nM = 11;
                        }
                        else
                        {
                            nM = 10;
                        }
                        int Oct = 31;
                        int mon = Oct;
                    }
                    else if (nM == 11)
                    {
                        if (nD > 30)
                        {
                            nM = 12;
                        }
                        else
                        {
                            nM = 11;
                        }
                        int Nov = 30;
                        int mon = Nov;
                    }
                    else if (nM == 12)
                    {
                        if (nD > 31)
                        {
                            nM = 1;
                            int newY = nY + 1;
                            Console.WriteLine(newY);
                        }
                        else
                        {
                            nM = 12;
                        }
                        int Dec = 31;
                        int mon = Dec;
                       
                    }
                #endregion
                Console.WriteLine($"New date is {nM}-{newD}-{nY}");
            Console.WriteLine();
            }
           

            
            Console.Read();
        }
        
    }
}
